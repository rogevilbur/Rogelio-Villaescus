document.getElementById('registroForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const data = new FormData(this);

    fetch('ruta/para/registro', {
        method: 'POST',
        body: data
    })
    .then(response => response.json())
    .then(result => alert(result.mensaje));
});